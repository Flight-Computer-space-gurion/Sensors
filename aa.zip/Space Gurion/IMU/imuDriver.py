import serial
import numpy as np

PACKET_SIZE = 36
ACCELERATION_FACTOR = (2**15)
GYRO_FACTOR = (2**12)
TWOS_COMPLIMENT_FACTOR = (1 << 23)
TEMPERATURE_FACTOR = 10

def values_adapt(value, factor):
    # Check if the most significant bit is set
    if value & TWOS_COMPLIMENT_FACTOR:
        value = 0xFFFFFF - value + 1 #twos_complement(value)
        # Convert to signed 32-bit integer
        value = np.int32(-value)
    retval = value / factor
    return retval

class MainStatus:
    def __init__(self, val):
        self.val = val
        self.high_g_sensor_in_all_axes = 0
        self.acc_x_ok = 0
        self.acc_y_ok = 0
        self.acc_z_ok = 0
        self.gyro_x_ok = 0
        self.gyro_y_ok = 0
        self.gyro_z_ok = 0
        self.sync_signal_exists = 0
        self.normal_mode = 0
        self.BIT_mode = 0
        self.fault_mode = 0
        self.gyro_ranges_ok = 0

    def set(self, val):
        self.val = val
        self.high_g_sensor_in_all_axes = bool(val & (1 << 4))
        self.acc_x_ok = not bool(val & (1 << 5))
        self.acc_y_ok = not bool(val & (1 << 6))
        self.acc_z_ok = not bool(val & (1 << 7))
        self.gyro_x_ok = not bool(val & (1 << 9))
        self.gyro_y_ok = not bool(val & (1 << 10))
        self.gyro_z_ok = not bool(val & (1 << 11))
        self.sync_signal_exists = not bool(val & (1 << 12))
        self.normal_mode = not bool(val & 0x6000)
        self.BIT_mode = bool(val & (1 << 13))
        self.fault_mode = bool(val & (1 << 13)) and bool(val & (1 << 14))
        self.gyro_ranges_ok = not bool(val & (1 << 15))

class IMU:
    def __init__(self, com_port, baudrate):
        # Open the serial port with the specified baudrate
        self.ser = serial.Serial(com_port, baudrate=baudrate)
        self.main_status = MainStatus(0)
        self.gyro_axis_x = 0
        self.gyro_axis_y = 0
        self.gyro_axis_z = 0
        self.accelerometer_axis_x = 0
        self.accelerometer_axis_y = 0
        self.accelerometer_axis_z = 0
        self.accelerometer_axis_x_high_g = 0
        self.temperature = 0
        self.sw_version = 0
        self.counter = 0
        self.crc = 0

    def get(self):
        packet = []
        while True:
            # Wait for the start of packet byte (0x24)
            start_byte = self.ser.read()
            if start_byte == b'\x24':
                packet.append(start_byte)
                # Read the rest of the packet
                for i in range(1, 36):
                    packet.append(self.ser.read())

                # Check if the end of packet byte (0x23) is present
                if packet[PACKET_SIZE - 1] == b'\x23':
                    # Parse the received packet
                    self.parse_packet(packet)
                    self.sensor_values_adaptions()
                    return self
                else:
                    # Start over and discard partial packet
                    packet = []
            else:
                # Discard garbage bytes before the start of packet
                packet = []

    def parse_packet(self, packet):
        # Convert the packet list to bytes
        packet_int = [int.from_bytes(x, byteorder='little') for x in packet]
        # Extract the main_status and gyro_axis_x fields
        self.main_status = MainStatus(0)
        self.main_status.set(packet_int[5] + (packet_int[6] << 8))
 
