import serial

packet_size = 36
acccel_factor = 2**15
gyro_factor = 2**12

imu = serial.Serial('/dev/ttyUSB0', 1250000)
interval = 0
print("Hello")
while 1:
    print(" -- interval ",interval," -- ")
    byte = imu.read()
    print(byte)