import datetime
import os
import time
import board
import busio
import adafruit_bmp280
import serial
import numpy as np
import adafruit_gps


# Generate a timestamp
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

# Formulate the filename based on the timestamp
filename = f"file_{timestamp}.txt"

# Get the desktop directory
desktop_dir = "/tmp/" # "/home/spacegurion/Desktop/"

# Combine desktop directory with filename
full_path = os.path.join(desktop_dir, filename)

# Open a new file for writing
with open(full_path, 'w') as file:
    # Write content into the file
    file.write("Hello, this is a new file!\n")
    file.write("It is created using Python on a Raspberry Pi.\n")
    file.write("This is a live example! #2")
   
print(f"File '{full_path}' created successfully.")

# =========================================================
# Barometric

# Create I2C bus interface
i2c = busio.I2C(board.SCL, board.SDA)

# Create BMP280 object
bmp280 = adafruit_bmp280.Adafruit_BMP280_I2C(i2c)

# Optional: change the sea level pressure (in hPa) to your local value
bmp280.sea_level_pressure = 1013.25

def read_bmp280():
    try:
        temperature = bmp280.temperature
        pressure = bmp280.pressure
        altitude = bmp280.altitude

        print(f"Temperature: {temperature:.2f} C")
        print(f"Pressure: {pressure:.2f} hPa")
        print(f"Altitude: {altitude:.2f} meters")

    except Exception as e:
        print(f"Failed to read from BMP280 sensor: {e}")

if __name__ == "__main__":
    while True:
        read_bmp280()
        time.sleep(1)

# =========================================================
# IMU


PACKET_SIZE = 36
ACCELERATION_FACTOR = (2**15)
GYRO_FACTOR = (2**12)
TWOS_COMPLIMENT_FACTOR = (1 << 23)
TEMPERATURE_FACTOR = 10

def values_adapt(value, factor):
    # Check if the most significant bit is set
    if value & TWOS_COMPLIMENT_FACTOR:
        value = 0xFFFFFF - value + 1 #twos_complement(value)
        # Convert to signed 32-bit integer
        value = np.int32(-value)
    retval = value / factor
    return retval

class MainStatus:
    def __init__(self, val):
        self.val = val
        self.high_g_sensor_in_all_axes = 0
        self.acc_x_ok = 0
        self.acc_y_ok = 0
        self.acc_z_ok = 0
        self.gyro_x_ok = 0
        self.gyro_y_ok = 0
        self.gyro_z_ok = 0
        self.sync_signal_exists = 0
        self.normal_mode = 0
        self.BIT_mode = 0
        self.fault_mode = 0
        self.gyro_ranges_ok = 0

    def set(self, val):
        self.val = val
        self.high_g_sensor_in_all_axes = bool(val & (1 << 4))
        self.acc_x_ok = not bool(val & (1 << 5))
        self.acc_y_ok = not bool(val & (1 << 6))
        self.acc_z_ok = not bool(val & (1 << 7))
        self.gyro_x_ok = not bool(val & (1 << 9))
        self.gyro_y_ok = not bool(val & (1 << 10))
        self.gyro_z_ok = not bool(val & (1 << 11))
        self.sync_signal_exists = not bool(val & (1 << 12))
        self.normal_mode = not bool(val & 0x6000)
        self.BIT_mode = bool(val & (1 << 13))
        self.fault_mode = bool(val & (1 << 13)) and bool(val & (1 << 14))
        self.gyro_ranges_ok = not bool(val & (1 << 15))

class IMU:
    def __init__(self, com_port, baudrate):
        # Open the serial port with the specified baudrate
        self.ser = serial.Serial(com_port, baudrate=baudrate)
        self.main_status = MainStatus(0)
        self.gyro_axis_x = 0
        self.gyro_axis_y = 0
        self.gyro_axis_z = 0
        self.accelerometer_axis_x = 0
        self.accelerometer_axis_y = 0
        self.accelerometer_axis_z = 0
        self.accelerometer_axis_x_high_g = 0
        self.temperature = 0
        self.sw_version = 0
        self.counter = 0
        self.crc = 0

    def get(self):
        packet = []
        while True:
            # Wait for the start of packet byte (0x24)
            start_byte = self.ser.read()
            if start_byte == b'\x24':
                packet.append(start_byte)
                # Read the rest of the packet
                for i in range(1, 36):
                    packet.append(self.ser.read())

                # Check if the end of packet byte (0x23) is present
                if packet[PACKET_SIZE - 1] == b'\x23':
                    # Parse the received packet
                    self.parse_packet(packet)
                    self.sensor_values_adaptions()
                    return self
                else:
                    # Start over and discard partial packet
                    packet = []
            else:
                # Discard garbage bytes before the start of packet
                packet = []

    def parse_packet(self, packet):
        # Convert the packet list to bytes
        packet_int = [int.from_bytes(x, byteorder='little') for x in packet]
        # Extract the main_status and gyro_axis_x fields
        self.main_status = MainStatus(0)
        self.main_status.set(packet_int[5] + (packet_int[6] << 8))
        self.gyro_axis_x = packet_int[8] + (packet_int[9] << 8) + (packet_int[10] << 16)
        self.gyro_axis_y = packet_int[11] + (packet_int[12] << 8) + (packet_int[13] << 16)
        self.gyro_axis_z = packet_int[14] + (packet_int[15] << 8) + (packet_int[16] << 16)
        self.accelerometer_axis_x = packet_int[17] + (packet_int[18] << 8) + (packet_int[19] << 16)
        self.accelerometer_axis_y = packet_int[20] + (packet_int[21] << 8) + (packet_int[22] << 16)
        self.accelerometer_axis_z = packet_int[23] + (packet_int[24] << 8) + (packet_int[25] << 16)
        self.accelerometer_axis_x_high_g = packet_int[26] + (packet_int[27] << 8) + (packet_int[28] << 16)
        self.temperature = packet_int[29] + (packet_int[30] << 8)
        self.sw_version = packet_int[31]
        self.counter = packet_int[32]
        self.crc = packet_int[33] + (packet_int[34] << 8)

    
    
    def sensor_values_adaptions(self):
        # Convert the values to floats
        self.gyro_axis_x = values_adapt(self.gyro_axis_x, GYRO_FACTOR)
        self.gyro_axis_y = values_adapt(self.gyro_axis_y, GYRO_FACTOR)
        self.gyro_axis_z = values_adapt(self.gyro_axis_z, GYRO_FACTOR)
        self.accelerometer_axis_x = values_adapt(self.accelerometer_axis_x, ACCELERATION_FACTOR)
        self.accelerometer_axis_y = values_adapt(self.accelerometer_axis_y, ACCELERATION_FACTOR)
        self.accelerometer_axis_z = values_adapt(self.accelerometer_axis_z, ACCELERATION_FACTOR) - 1 # Since IMU senses gravity, 1g must be added, at the current configuration at the vehicle it is sensed through X axis
        self.accelerometer_axis_x_high_g = values_adapt(self.accelerometer_axis_x_high_g, ACCELERATION_FACTOR)
        self.temperature = self.temperature / TEMPERATURE_FACTOR
        
if __name__ == "__main__":
    imu = IMU('/dev/ttyUSB0', 1250000)
    imu.get()
    while True:
        imu.get()
        print("Gyro X: ", imu.gyro_axis_x, " Gyro Y: ", imu.gyro_axis_y, " Gyro Z: ", imu.gyro_axis_z)
        print("Accel X: ", imu.accelerometer_axis_x, " Accel Y: ", imu.accelerometer_axis_y, " Accel Z: ", imu.accelerometer_axis_z)
        print("Temperature: ", imu.temperature)

        # Clear the terminal
        os.system('clear')
        print("\n")
        
# =========================================================
# GPS

# Create a serial connection for the GPS module using default speed and a slightly higher timeout.
# GPS modules typically update once a second.
# For other boards set RX = GPS module TX, and TX = GPS module RX pins.
# For a computer, use the pyserial library for UART access.
import serial
uart = serial.Serial("/dev/serial0", baudrate=9600, timeout=10)

# If using I2C, you can create an I2C interface to talk to using default pins.
# i2c = board.I2C()  # uses board.SCL and board.SDA
# i2c = board.STEMMA_I2C()  # For using the built-in STEMMA QT connector on a microcontroller

# Create a GPS module instance.
gps = adafruit_gps.GPS(uart, debug=False)  # Use UART/pyserial
# gps = adafruit_gps.GPS_GtopI2C(i2c, debug=False)  # Use I2C interface

# Initialize the GPS module by changing what data it sends and at what rate.
# These are NMEA extensions for PMTK_314_SET_NMEA_OUTPUT and PMTK_220_SET_NMEA_UPDATERATE.
# You can adjust the GPS module's behavior using these commands.
# More details can be found in the datasheet: https://cdn-shop.adafruit.com/datasheets/PMTK_A11.pdf
# Explanation for each gps.send_command() parameter:
# PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
# This command sets the NMEA output sentences to GGA, RMC, VTG, GSA, GSV, and GLL.
# The parameters are as follows:
# - $PMTK314: Command header
# - 0: GGA sentence (Global Positioning System Fix Data) - Disable
# - 1: RMC sentence (Recommended Minimum Specific GNSS Data) - Enable
# - 0: VTG sentence (Course Over Ground and Ground Speed) - Disable
# - 1: GSA sentence (GNSS DOP and Active Satellites) - Enable
# - 0: GSV sentence (GNSS Satellites in View) - Disable
# - 0: GLL sentence (Geographic Position - Latitude/Longitude) - Disable
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
# - 0: Reserved
gps.send_command(b"PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0")

# Set update rate to once a second (1hz), which is typical.
gps.send_command(b"PMTK220,1000")

# Main loop runs forever, printing the location details every second.
last_print = time.monotonic()
while True:
    # Make sure to call gps.update() every loop iteration and at least twice
    # as fast as data comes from the GPS unit (usually every second).
    # This returns a bool that's true if it parsed new data.
    gps.update()

    # Every second, print out current location details if there's a fix.
    current = time.monotonic()
    if current - last_print >= 1.0:
        last_print = current
        if not gps.has_fix:
            # Try again if we don't have a fix yet.
            print("Waiting for fix...")
            continue

        # We have a fix! (gps.has_fix is true)
        # Print out details about the fix like location, date, etc.
        print("=" * 40)  # Print a separator line.
        print(
            "Fix timestamp: {}/{}/{} {:02}:{:02}:{:02}".format(
                gps.timestamp_utc.tm_mon,  # Grab parts of the time from the struct_time object.
                gps.timestamp_utc.tm_mday,
                gps.timestamp_utc.tm_year,
                gps.timestamp_utc.tm_hour,
                gps.timestamp_utc.tm_min,
                gps.timestamp_utc.tm_sec,
            )
        )
        print("Latitude: {:.6f} degrees".format(gps.latitude))
        print("Longitude: {:.6f} degrees".format(gps.longitude))
        print(
            "Precise Latitude: {:2.0f}{:2.4f} degrees".format(
                gps.latitude_degrees, gps.latitude_minutes
            )
        )
        print(
            "Precise Longitude: {:3.0f}{:2.4f} degrees".format(
                gps.longitude_degrees, gps.longitude_minutes
            )
        )
        print("Fix quality: {}".format(gps.fix_quality))

        # Check if additional attributes are not None before printing them.
        if gps.satellites is not None:
            print("# satellites: {}".format(gps.satellites))
        if gps.altitude_m is not None:
            print("Altitude: {} meters".format(gps.altitude_m))
        if gps.speed_knots is not None:
            print("Speed: {} knots".format(gps.speed_knots))
        if gps.track_angle_deg is not None:
            print("Track angle: {} degrees".format(gps.track_angle_deg))
        if gps.horizontal_dilution is not None:
            print("Horizontal dilution: {}".format(gps.horizontal_dilution))
        if gps.height_geoid is not None:
            print("Height geoid: {} meters".format(gps.height_geoid))