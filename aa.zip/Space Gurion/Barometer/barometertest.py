import time
import board
import busio
import adafruit_bmp280

# Create I2C bus interface
i2c = busio.I2C(board.SCL, board.SDA)

# Create BMP280 object
bmp280 = adafruit_bmp280.Adafruit_BMP280_I2C(i2c)

# Optional: change the sea level pressure (in hPa) to your local value
bmp280.sea_level_pressure = 1013.25

def read_bmp280():
    try:
        temperature = bmp280.temperature
        pressure = bmp280.pressure
        altitude = bmp280.altitude

        print(f"Temperature: {temperature:.2f} C")
        print(f"Pressure: {pressure:.2f} hPa")
        print(f"Altitude: {altitude:.2f} meters")

    except Exception as e:
        print(f"Failed to read from BMP280 sensor: {e}")

if __name__ == "__main__":
    while True:
        read_bmp280()
        time.sleep(1)
